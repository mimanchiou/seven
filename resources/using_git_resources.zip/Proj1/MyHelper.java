public class MyHelper {

	public static void displayDateTime() {
		// Display the current date and time.
		System.out.println("It is now " + new java.util.Date());
	}
}
