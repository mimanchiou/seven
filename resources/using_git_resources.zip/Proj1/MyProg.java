public class MyProg {

	public static void main(String[] args) {

		// Display a hello message.
		System.out.println("Hello from my program.");

		// Invoke a method on MyHelper class.
		MyHelper.displayDateTime();

		// Display a goodbye message.
		System.out.println("Goodbye from my program.");
	}
}
